x = 0
y = 0

def init(a, b):
    global x
    global y
    x = a
    y = b

def devision():
    return x // y

def ostatok():
    return x % y


